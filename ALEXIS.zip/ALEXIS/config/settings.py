CLINICALTRIALS_API_BASE = "https://clinicaltrials.gov/api/v2/studies"
CLINICALTRIALS_PAGE_SIZE = 10
DEFAULT_CONDITION_QUERY = "cancer"